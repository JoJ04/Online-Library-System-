package com.mycompany.online_library_management_system;


public class Online_Library_Management_System {

    public static void main(String[] args) {
        new SignLogin();
       
    }
}
